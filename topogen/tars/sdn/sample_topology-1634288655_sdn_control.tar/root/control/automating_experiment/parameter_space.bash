eplb hs
1 1
udp tcp
3 : 1 3
cbr vbr bursty
3
4
1 : 2 3 4
sample_topology

