ovs-ofctl dump-flows br -O OpenFlow13
