#!/bin/bash
f=1
while [ $f -eq 1 ]
do
  scp -p con0:detector_multidigraph/detector_log_*  dataset/
  log=$(ssh con0 "ls detector_multidigraph/detector_log_*")
  cl=$(ssh con0 "cat detector_multidigraph/detector_log_filename") #current log
  echo "current log = $cl"
  for i in $log; do
    [[ $i != *"$cl"* && $i != *"detector_log_filename" ]] && echo "remove $i" && ssh con0 "rm $i"
  done
  ssh con0 "apt-get clean"
  echo 
  sleep 600
done
