#!/bin/bash
# pass application name as argument without the .py extension
# example:
# bash collectdata.bash appsuite_v4_0 ryu_multipath
# $1 is the point number, for app deployment in isolation, $1 is appname_config
# $2 $3 is source group and destination group in traffic generation.
# $4 is the limit of rules that will cause this script to be stopped
# $5 ping control: 0 no ping between end-points, 1 ping
. ./collectdata_config.bash
. ./collectdata_function.bash

if [ "$#" -gt 4 ] && [ "$5" == "iso" ]
then
  	fw=$(echo "$1" | grep "fw" -c)
  	if [ "$fw" != "0" ]
	then
		CONFLICT_FILE=""
		echo "Isolated run for fw, ignoring errors for connections"
	fi
fi

[ -z $4 ] && lim=1000 || lim=$4
echo "limit = $lim"
#do ping between end-hosts

# perform traffic generation for all combinations of end-points between source set and destination set with iperf, nc to transfer files, using tcp, udp. Note: this handles only unicast, not multicast.
#trap 'ssh -n ' INT

# ping from every source pc to dst pc to fill arpcache an make experiments more stable
if [[ "$5" -eq 1 ]] 
then 
for src in $2; do
  for dst in $3; do
    ssh -n pc$src "sh -c 'ping 192.168.1.$dst -w 3 -c 2'"
  done
done
fi

#starting nc testing
#new approach: that allow concurrent nc test --> each server will have to listen on multiple ports
for src in $2; do
  for dst in $3; do
    for dst1 in $3; do #all dst will listen on port 34$src$dst (so for each round a src connects to a dst via nc, the port at the dst is unique and always available for this connection), so the effect of SBEpLB, that directing a session to another server (which we usually don't know) will cause no problem of a server not listening on a port.
      serport=34$src$dst #server port
      [ $serport -gt 65000 ] && serport=$(alternative_port $serport)
      ssh -n pc$dst1 "sh -c 'pgrep -a nc | grep $serport >/dev/null 2>&1'"
      [ $? -eq 0 ] && echo "nc server  already running at pc$dst1" && continue #already running, don't have to start nc server at this end-point
      echo "SERVER: starting nc server at pc$dst1, port $serport"
      ssh -n pc$dst1 "sh -c 'nc -lvp $serport >> tmpnc_recv_$1 2>&1 &'"
    done
  done
done
for src in $2; do
  for dst in $3; do
    serport=34$src$dst #server port
    [ $serport -gt 65000 ] && serport=$(alternative_port $serport)
    #tcpdump to get the temporary client port used to connect to server, which will be extracted later in the client.
    #ssh -n pc$src "sh -c 'tcpdump -ieth1 tcp port $serport > tmptcpdump.txt 2>&1 &'"
    echo "CLIENT: nc from pc$src to pc$dst"
    #ssh -n pc$src "sh -c 'echo -n nc from pc$src to pc$dst > tmpnc$dst; for i in {1..5}; do echo $i; sleep 0.3; done  | nc -w 3 -p 23$src$dst 192.168.1.$dst 34$src$dst >> tmpnc$dst 2>&1 &'"#when specifying the source port with -p switch, the error "Cannot assign requested address" occurs quite often, rewrite: net.ipv4.tcp_tw_reuse = 1 in the target host to allow reusing time_wait connection.
    ssh -n pc$src "sh -c 'echo -n nc from pc$src to pc$dst > tmpnc$dst; for i in {1..5}; do echo $i; sleep 0.3; done  | nc -w 3 192.168.1.$dst $serport >> tmpnc$dst 2>&1 &'"#when specifying the source port with -p switch, the error "Cannot assign requested address" occurs quite often.
    sleep 11 # each run is 3 seconds one after another, seems like this help the result always be consistent, i.e., the 10 times re-run still yields the same output
    #now extract the client port from tcpdump result.
    #ssh -n pc$src "sh -c 'pkill -f \"tcpdump -ieth1 tcp port $serport\"'"
    #eval portnc$src$dst=$(ssh -n pc$src "sh -c 'grep -m 1 \"192.168.1.$src.\+ >\" tmptcpdump.txt'" | awk '{print $3}' | cut -d'.' -f5)
    #ssh -n pc$src "sh -c 'grep \"192.168.1.$src.\+ >\" tmptcpdump.txt'" | awk '{print $3}' | cut -d'.' -f5
    #eval tmpportnc=\$portnc$src$dst
    #echo tmpportnc = $tmpportnc
  done
done
sleep 20
#now check the logfile of nc if there is any problem.
for src in $2; do
  for dst in $3; do
    ssh -n pc$src "sh -c 'grep UNKNOWN tmpnc$dst'" 
    #[ $? -eq 0 ] && echo "error with nc, point = $1" | tee -a $CONFLICT_FILE
    #ssh -n pc$src "sh -c 'grep UNKNOWN tmpnc$dst'" | tee -a $CONFLICT_FILE
  done
done

echo "limit = $lim"
count=$(ssh -n con0 "sh -c 'cd detector_multidigraph; grep \"Number of rules:\" detector_log | tail -1'" | sed -e 's/.*\[\([0-9]\+\), {.*/\1/')
echo "Number of rules = $count"
[[ "$count" -ge $lim ]] && echo "limit reached" && exit 0

#start iperf traffic
for src in $2; do
  #echo $src
  for dst in $3; do
    ssh -n pc$dst "sh -c 'pgrep -a iperf >/dev/null 2>&1'"
    [ $? -eq 0 ] && echo "iperf already running at pc$dst" && continue #already running, don't have to start iperf server at this end-point
    #echo $dst
    echo "SERVER: starting iperf server at pc$dst"
    #ssh -n pc$dst "sh -c 'pkill iperf; iperf -s -u &' >/dev/null"
    #ssh -n pc$dst "sh -c 'iperf -s -u &' >/dev/null"
    ssh -n pc$dst "sh -c 'iperf -s -u >> tmpiperf_recv_$1 2>&1 &'"
  done
  for dst in $3; do
    echo "CLIENT: iperf from pc$src to pc$dst"
    #ssh -n pc$src "sh -c 'iperf -c 192.168.1.$dst -u -b 20M -t 20'" 2>&1 | tee temp.txt
    #ssh -n pc$src "sh -c 'iperf -c 192.168.1.$dst -u -b 5m -t 20'" >> temp.txt 2>&1 &
    ssh -n pc$src "sh -c 'echo iperf from pc$src to pc$dst > tmpiperf$dst; iperf -c 192.168.1.$dst -u -b 5m -t 20 >> tmpiperf$dst 2>&1 &'"
    sleep 30
    #grep "WARNING" temp.txt > /dev/null && [ $? -eq 0 ] && (echo "error! iperf from pc$src to pc$dst, point = $1" | tee -a $CONFLICT_FILE) && (grep "WARNING" temp.txt >> $CONFLICT_FILE)
  done
done
sleep 20
#echo $CONFLICT_FILE
#cat temp.txt
#grep "WARNING" temp.txt
#grep "WARNING" temp.txt > /dev/null && [ $? -eq 0 ] && (echo "error with iperf, point = $1" | tee -a $CONFLICT_FILE) && (grep "WARNING" temp.txt >> $CONFLICT_FILE)
# now check the logfile of iperf if there is any problem.
for src in $2; do
  for dst in $3; do
    ssh -n pc$src "sh -c 'grep WARNING tmpiperf$dst'" 
    #[ $? -eq 0 ] && echo -n "error with iperf, point = $1, " | tee -a $CONFLICT_FILE && ssh -n pc$src "sh -c 'sed -n 1p tmpiperf$dst; grep WARNING tmpiperf$dst'" | tee -a $CONFLICT_FILE
    #extract the port, then replace it in the dumpflow file later, so that the merging and comparing of flow table is more precise.
    #eval portiperf$src$dst=$(ssh -n pc$src "sh -c 'grep \"connected with\" tmpiperf$dst'" | awk '{print $6}') 
  done
done
sleep 20


echo "limit = $lim"
count=$(ssh -n con0 "sh -c 'cd detector_multidigraph; grep \"Number of rules:\" detector_log | tail -1'" | sed -e 's/.*\[\([0-9]\+\), {.*/\1/')
echo "Number of rules = $count"
[[ "$count" -ge $lim ]] && echo "limit reached" && exit 0
