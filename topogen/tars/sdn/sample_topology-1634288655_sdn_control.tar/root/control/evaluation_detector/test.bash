lim=10000
count=$(ssh -n con0 "sh -c 'cd detector_multidigraph; grep \"Number of rules:\" detector_log | tail -1'" | sed -e 's/.*\[\([0-9]\+\), {.*/\1/')
echo "Number of rules = $count"
[ $count -ge $lim ] && echo "limit reached"
a=$1
b=$2
echo $a
echo $b
[ -z $a ] && echo "no first variable"
