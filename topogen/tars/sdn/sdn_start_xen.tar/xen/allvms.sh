#!/bin/bash

########################  ATTENTION  #######################################
#Please make sure that you modify /etc/init.d/rnp_vms if you make changes  #
#in the start parameters. Thank you!					   #
############################################################################

XEN_DOMAIN_DIR=/xen/domains
RETRY_COUNTER=3

checkVM()
{
  if [ $RETRY_COUNTER -gt 0 ]
  then 
    let RETRY_COUNTER--
    vmStarted=$(xl list | grep -c $1)
    if [ $vmStarted -eq 0 ]
    then
      createVM $1
    fi
  fi
  let RETRY_COUNTER=3
}

createVM()
{
  xl create ${XEN_DOMAIN_DIR}/$1/$1.cfg
  sleep 2
  checkVM $1
}

updateControllerConfig()
{
  isController=$(echo $1 | grep -c -e "con*")
  if [ $isController -eq 1 ]
  then
    sed -i -e "s/memory.*/memory = '512'/" ${XEN_DOMAIN_DIR}/$1/$1.cfg
    sed -i -e "s/maxmem.*/maxmem = '512'/" ${XEN_DOMAIN_DIR}/$1/$1.cfg
    cpus=$(echo $(lscpu) | grep -o -E "CPU\(s\):\s[1-9]+" | awk '{print $2}') 
    if [ $cpus -gt 2 ]
    then
      sed -i -e "s/vcpus.*/vcpus = '2'/" ${XEN_DOMAIN_DIR}/$1/$1.cfg
    fi
  fi
}

case $1 in 
  start)
    for f in $(ls ${XEN_DOMAIN_DIR}) ; do updateControllerConfig $f && createVM $f; done ;;
  shutdown)
    for f in $(ls ${XEN_DOMAIN_DIR}) ; do xl shutdown $f & done ;;
  destroy)
    for f in $(ls ${XEN_DOMAIN_DIR}) ; do xl destroy $f & done ;;
  editcfg)
    find ${XEN_DOMAIN_DIR} -type f -name "*.cfg" | xargs gvim -p ;;
  *)
    echo Unknown verb.
    exit 1 ;;
esac

exit 0
